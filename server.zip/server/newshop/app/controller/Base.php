<?php
// +----------------------------------------------------------------------
// | 资源控制器基类
// +----------------------------------------------------------------------

namespace app\controller;

use think\Controller;

abstract class Base extends Controller
{

}
