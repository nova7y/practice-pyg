<?php

namespace app\model;

use think\Model;

class OrderGoods extends Model
{
    protected $pk = 'id';
}
