<?php

namespace app\model;

use think\Model;

class Goods extends Model
{
    protected $pk = 'goods_id';
}
