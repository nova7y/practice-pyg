<?php

namespace app\model;

use think\Model;

class Express extends Model
{
    protected $pk = 'express_id';
}
