<?php

namespace app\model;

use think\Model;

class Consignee extends Model
{
    protected $pk = 'cgn_id';
}
