<?php

namespace app\model;

use think\Model;

class User extends Model
{
    protected $pk = 'user_id';
}
