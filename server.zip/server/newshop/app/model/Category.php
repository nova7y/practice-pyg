<?php

namespace app\model;

use think\Model;

class Category extends Model
{
    protected $pk = 'cat_id';
}
