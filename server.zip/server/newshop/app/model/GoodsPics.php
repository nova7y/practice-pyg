<?php

namespace app\model;

use think\Model;

class GoodsPics extends Model
{
    protected $pk = 'pics_id';
}
