<?php

namespace app\model;

use think\Model;

class UserCart extends Model
{
    protected $pk = 'cart_id';
}
