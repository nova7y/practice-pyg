Route List
+------------------------------------+-------------------+--------+-------------------+--------+
| Rule                               | Route             | Method | Name              | Domain |
+------------------------------------+-------------------+--------+-------------------+--------+
| v1/settings/<key>                  | Setting/read      | get    | Setting/read      |        |
| v1/settings                        | Setting/index     | get    | Setting/index     |        |
| v1/categories/<id>/products        | Product/category  | get    | Product/category  |        |
| v1/categories/<id>/children        | Category/children | get    | Category/children |        |
| v1/categories/<id>                 | Category/read     | get    | Category/read     |        |
| v1/categories                      | Category/index    | get    | Category/index    |        |
| v1/products/<id>                   | Product/read      | get    | Product/read      |        |
| v1/products                        | Product/index     | get    | Product/index     |        |
| v1/users/login                     | User/login        | post   | User/login        |        |
| v1/users/register                  | User/register     | post   | User/register     |        |
| v1/users/exists                    | User/exists       | get    | User/exists       |        |
| v1/users/<id>/active               | User/active       | post   | User/active       |        |
| v1/users/<id>/active               | User/unactive     | delete | User/unactive     |        |
| v1/users/<id>/address/<address_id> | Address/delete    | delete | Address/delete    |        |
| v1/users/<id>/address/<address_id> | Address/update    | patch  | Address/update    |        |
| v1/users/<id>/address/<address_id> | Address/read      | get    | Address/read      |        |
| v1/users/<id>/address              | Address/save      | post   | Address/save      |        |
| v1/users/<id>/address              | Address/index     | get    | Address/index     |        |
| v1/users/<id>/cart/<cart_id>       | Cart/delete       | delete | Cart/delete       |        |
| v1/users/<id>/cart/<cart_id>       | Cart/update       | patch  | Cart/update       |        |
| v1/users/<id>/cart                 | Cart/save         | post   | Cart/save         |        |
| v1/users/<id>/cart                 | Cart/index        | get    | Cart/index        |        |
| v1/users/<id>                      | User/delete       | delete | User/delete       |        |
| v1/users/<id>                      | User/update       | patch  | User/update       |        |
| v1/users/<id>                      | User/read         | get    | User/read         |        |
| v1/orders/<num>                    | Order/delete      | delete | Order/delete      |        |
| v1/orders/<num>                    | Order/update      | patch  | Order/update      |        |
| v1/orders/<num>                    | Order/read        | get    | Order/read        |        |
| v1/orders                          | Order/save        | post   | Order/save        |        |
| v1/orders                          | Order/index       | get    | Order/index       |        |
| v1                                 | Index/index       | get    | Index/index       |        |
+------------------------------------+-------------------+--------+-------------------+--------+
